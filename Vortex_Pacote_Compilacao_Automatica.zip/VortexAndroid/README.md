# Vortex Android — projeto inicial pronto para abrir no Android Studio

Este é um protótipo de player offline para Android, feito em Kotlin + Jetpack Compose.

## Incluído
- Interface escura com detalhes vermelhos.
- Abas Início, Buscar, Biblioteca e Downloads.
- Importação de arquivos de áudio usando o seletor do Android.
- Reprodução local com Media3/ExoPlayer.
- Lista de faixas e pesquisa na biblioteca.
- Salva os URIs importados localmente para tentar restaurar a biblioteca depois de fechar e reabrir o app.

## Limitações honestas
- Este projeto ainda não é um APK compilado.
- Não inclui catálogo comercial/streaming nem downloads de músicas protegidas. Só reproduz arquivos locais que você já tem ou que obtenha de fontes autorizadas.
- Não inclui ainda serviço de reprodução contínua em segundo plano, equalizador real, letras, capas personalizadas ou gestão completa de playlists.
- A versão precisa ser compilada e testada no Android Studio.

## Como gerar o APK
1. Instale o Android Studio pelo site oficial: https://developer.android.com/studio
2. Extraia o ZIP.
3. Abra o Android Studio > Open e selecione a pasta `VortexAndroid`.
4. Aguarde a sincronização do Gradle e aceite instalar os componentes solicitados.
5. Para gerar APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
6. O APK de teste normalmente aparece em `app/build/outputs/apk/debug/app-debug.apk`.

## Como rodar no celular via USB
1. Ative as Opções do desenvolvedor no Android (toque 7 vezes em “Número da versão” nas informações do software).
2. Ative “Depuração USB”.
3. Conecte o celular ao computador e autorize a depuração no celular.
4. No Android Studio, escolha seu aparelho na lista e pressione Run (triângulo verde).

Se a sincronização/compilação der erro, copie a mensagem ou envie uma captura de tela para diagnosticar.
