package com.example.vortex

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import org.json.JSONArray
import org.json.JSONObject

private val Black = Color(0xFF050505)
private val Panel = Color(0xFF171719)
private val Red = Color(0xFFFF1744)
private val Muted = Color(0xFFAAAAAF)

data class Track(val title: String, val uri: Uri)

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent {
            VortexApp(
                onPlay = { track ->
                    player.setMediaItem(MediaItem.fromUri(track.uri))
                    player.prepare()
                    player.play()
                },
                onTogglePlayback = {
                    if (player.isPlaying) player.pause() else player.play()
                }
            )
        }
    }

    override fun onDestroy() {
        if (::player.isInitialized) player.release()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VortexApp(onPlay: (Track) -> Unit, onTogglePlayback: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("vortex_library", 0) }
    val tracks = remember { mutableStateListOf<Track>() }
    var tab by remember { mutableStateOf("Início") }
    var search by remember { mutableStateOf("") }
    var playingTitle by remember { mutableStateOf("Escolha uma música") }
    var isPlaying by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val saved = prefs.getString("tracks", "[]") ?: "[]"
        try {
            val array = JSONArray(saved)
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val uri = Uri.parse(item.getString("uri"))
                try {
                    context.contentResolver.openFileDescriptor(uri, "r")?.close()
                    tracks.add(Track(item.getString("title"), uri))
                } catch (_: Exception) { /* arquivo removido ou permissão revogada */ }
            }
        } catch (_: Exception) { }
    }

    fun persistTracks() {
        val array = JSONArray()
        tracks.forEach { track ->
            array.put(JSONObject().put("title", track.title).put("uri", track.uri.toString()))
        }
        prefs.edit().putString("tracks", array.toString()).apply()
    }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        uris.forEach { uri ->
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) { }
            if (tracks.none { it.uri == uri }) {
                val rawName = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':') ?: "Áudio importado"
                val name = Uri.decode(rawName).substringAfterLast("%2F").take(100)
                tracks.add(Track(name, uri))
            }
        }
        persistTracks()
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Red, background = Black, surface = Panel,
            onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Black,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF101012), contentColor = Color.White) {
                    listOf(
                        "Início" to Icons.Default.Home,
                        "Buscar" to Icons.Default.Search,
                        "Biblioteca" to Icons.Default.LibraryMusic,
                        "Downloads" to Icons.Default.Download
                    ).forEach { (label, icon) ->
                        NavigationBarItem(
                            selected = tab == label,
                            onClick = { tab = label },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Red, selectedTextColor = Red,
                                indicatorColor = Color(0xFF321018),
                                unselectedIconColor = Muted, unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().background(Black).padding(padding)) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("▼", color = Red, fontSize = 24.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.width(10.dp))
                    Text("Vortex", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Default.Equalizer, null, tint = Red, modifier = Modifier.size(28.dp))
                }

                when (tab) {
                    "Início" -> {
                        Text("Sua música. Do seu jeito.", Modifier.padding(horizontal = 20.dp), fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        Text("Player offline • biblioteca pessoal", Modifier.padding(start = 20.dp, top = 5.dp), color = Muted)
                        Spacer(Modifier.height(20.dp))
                        Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                            Column(Modifier.padding(18.dp)) {
                                Text("OUÇA SEM INTERNET", color = Red, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text("Sua biblioteca, sempre com você.", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Text("Importe arquivos de áudio e reproduza-os offline.", color = Muted, modifier = Modifier.padding(top = 6.dp))
                                Button(onClick = { picker.launch(arrayOf("audio/*")) }, modifier = Modifier.padding(top = 14.dp), colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                                    Icon(Icons.Default.Add, null)
                                    Spacer(Modifier.width(6.dp))
                                    Text("Adicionar músicas")
                                }
                            }
                        }
                        SectionTitle("Sua biblioteca")
                        TrackList(tracks, "", onPlay = { track ->
                            playingTitle = track.title
                            isPlaying = true
                            onPlay(track)
                        })
                    }
                    "Buscar" -> {
                        Text("Buscar", Modifier.padding(horizontal = 20.dp), fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = search, onValueChange = { search = it },
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            placeholder = { Text("Pesquisar na sua biblioteca…") },
                            leadingIcon = { Icon(Icons.Default.Search, null) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Red, unfocusedBorderColor = Panel,
                                focusedContainerColor = Panel, unfocusedContainerColor = Panel
                            )
                        )
                        TrackList(tracks.filter { it.title.contains(search, ignoreCase = true) }, search,
                            onPlay = { track ->
                                playingTitle = track.title
                                isPlaying = true
                                onPlay(track)
                            })
                    }
                    "Biblioteca" -> {
                        Text("Biblioteca", Modifier.padding(horizontal = 20.dp), fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Text("${tracks.size} músicas importadas", Modifier.padding(horizontal = 20.dp, vertical = 8.dp), color = Muted)
                        Button(onClick = { picker.launch(arrayOf("audio/*")) }, Modifier.padding(horizontal = 16.dp), colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                            Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Importar áudio")
                        }
                        TrackList(tracks, "", onPlay = { track ->
                            playingTitle = track.title
                            isPlaying = true
                            onPlay(track)
                        })
                    }
                    else -> {
                        Text("Downloads", Modifier.padding(horizontal = 20.dp), fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Text("Arquivos de áudio locais disponíveis offline", Modifier.padding(horizontal = 20.dp, vertical = 8.dp), color = Muted)
                        if (tracks.isEmpty()) EmptyState("Sua área offline está vazia", "Importe arquivos de áudio para ouvi-los sem conexão.")
                        else TrackList(tracks, "", onPlay = { track ->
                            playingTitle = track.title
                            isPlaying = true
                            onPlay(track)
                        })
                    }
                }

                Spacer(Modifier.weight(1f, fill = false))
                Card(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1115)),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(44.dp).background(Color(0xFF35101B), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.MusicNote, null, tint = Red)
                        }
                        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                            Text(playingTitle, maxLines = 1, fontWeight = FontWeight.SemiBold)
                            Text(if (isPlaying) "Reproduzindo • offline" else "Player Vortex", color = Muted, fontSize = 12.sp)
                        }
                        IconButton(onClick = {
                            onTogglePlayback()
                            isPlaying = !isPlaying
                        }) {
                            Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Red, modifier = Modifier.size(30.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(title, Modifier.padding(start = 20.dp, top = 22.dp, bottom = 10.dp), fontSize = 19.sp, fontWeight = FontWeight.Bold)
}

@Composable
private fun EmptyState(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(26.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.LibraryMusic, null, tint = Red, modifier = Modifier.size(44.dp))
        Spacer(Modifier.height(10.dp))
        Text(title, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp))
    }
}

@Composable
private fun TrackList(tracks: List<Track>, query: String, onPlay: (Track) -> Unit) {
    val filtered = tracks.filter { it.title.contains(query, ignoreCase = true) }
    if (filtered.isEmpty()) {
        EmptyState("Nada por aqui ainda", "Use “Adicionar músicas” para importar arquivos de áudio.")
    } else {
        LazyColumn(Modifier.fillMaxWidth().heightIn(max = 360.dp)) {
            items(filtered) { track ->
                Row(
                    Modifier.fillMaxWidth().clickable { onPlay(track) }.padding(horizontal = 16.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(48.dp).background(Panel, RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.MusicNote, null, tint = Red)
                    }
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(track.title, maxLines = 1, fontWeight = FontWeight.SemiBold)
                        Text("Áudio local • offline", color = Muted, fontSize = 12.sp)
                    }
                    IconButton(onClick = { onPlay(track) }) {
                        Icon(Icons.Default.PlayCircle, null, tint = Red)
                    }
                }
            }
        }
    }
}
